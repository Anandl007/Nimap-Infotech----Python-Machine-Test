from django.contrib import admin  # Import admin
from django.urls import path, include  # Import include
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # This maps the root URL to the 'home' view
    path('admin/', admin.site.urls),
    path('clients/', include('clients.urls')),  # Assuming you're including the clients URLs

    # Add other URL patterns here
]